package com.example.firstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnClickMe = findViewById<Button>(R.id.mybutton)
        val myText = findViewById<TextView>(R.id.textView)
        var timeClicking = 0

        btnClickMe.setOnClickListener{
            timeClicking = timeClicking + 1
            myText.text = timeClicking.toString()
            Toast.makeText(this, "You Clicked" ,Toast.LENGTH_SHORT).show()


        }
    }
}